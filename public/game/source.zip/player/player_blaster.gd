extends Node2D

const BulletScene = preload("res://player/bullet.tscn")
const MissileScene = preload("res://player/missile.tscn")

@onready var blaster_sprite = $BlasterSprite
@onready var muzzle = $BlasterSprite/Muzzle

func _process(_delta):
	if MainInstances.player is Player:
		blaster_sprite.rotation = 0.0 if MainInstances.player.facing > 0 else PI

func fire_bullet():
	var bullet = Utils.instantiate_scene_on_level(BulletScene, muzzle.global_position)
	bullet.rotation = blaster_sprite.rotation
	bullet.update_velocity()

func fire_missile():
	var missile = Utils.instantiate_scene_on_level(MissileScene, muzzle.global_position)
	missile.rotation = blaster_sprite.rotation
	missile.update_velocity()
